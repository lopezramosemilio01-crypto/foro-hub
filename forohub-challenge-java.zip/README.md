
# ForoHub Challenge

API REST desarrollada con Spring Boot para gestionar tópicos de un foro.

## Endpoints

GET /topicos → listar tópicos  
POST /topicos → crear tópico  
DELETE /topicos/{id} → eliminar tópico

## Tecnologías

- Java
- Spring Boot
- JPA
- PostgreSQL
