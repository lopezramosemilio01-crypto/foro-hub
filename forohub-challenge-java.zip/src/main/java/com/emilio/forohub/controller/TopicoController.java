
package com.emilio.forohub.controller;

import org.springframework.web.bind.annotation.*;
import java.util.List;

import com.emilio.forohub.model.Topico;
import com.emilio.forohub.service.TopicoService;

@RestController
@RequestMapping("/topicos")
public class TopicoController {

    private final TopicoService service;

    public TopicoController(TopicoService service){
        this.service = service;
    }

    @GetMapping
    public List<Topico> listar(){
        return service.listar();
    }

    @PostMapping
    public Topico crear(@RequestBody Topico topico){
        return service.guardar(topico);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Long id){
        service.eliminar(id);
    }
}
