
package com.emilio.forohub.service;

import org.springframework.stereotype.Service;
import java.util.List;
import com.emilio.forohub.model.Topico;
import com.emilio.forohub.repository.TopicoRepository;

@Service
public class TopicoService {

    private final TopicoRepository repository;

    public TopicoService(TopicoRepository repository){
        this.repository = repository;
    }

    public List<Topico> listar(){
        return repository.findAll();
    }

    public Topico guardar(Topico topico){
        return repository.save(topico);
    }

    public void eliminar(Long id){
        repository.deleteById(id);
    }
}
