
package com.emilio.forohub.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.emilio.forohub.model.Topico;

public interface TopicoRepository extends JpaRepository<Topico, Long> {
}
